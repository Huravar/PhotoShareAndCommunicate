
//line x9.go:4
package main
func F9() {}
