// $G $D/$F.go $D/z*.go && $L $F.$A && ./$A.out

// NOTE: This test is not run by 'run.go' and so not run by all.bash.
// To run this test you must use the ./run shell script.

// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main
func main() {
F1()
F2()
F3()
F4()
F5()
F6()
F7()
F8()
F9()
F10()
F11()
F12()
F13()
F14()
F15()
F16()
F17()
F18()
F19()
F20()
}
